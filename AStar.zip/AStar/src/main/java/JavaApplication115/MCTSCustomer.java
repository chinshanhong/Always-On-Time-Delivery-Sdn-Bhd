package JavaApplication115;

import java.util.ArrayList;

public class MCTSCustomer {
    int x,y;//used to store x and y coordinate
    int demand_size; // used to store the capacity
    int id; //used to store assigned ID
    boolean visited = false;
    boolean checked = false;
    MCTSCustomer depot;
    ArrayList<MCTSCustomer> successor = new ArrayList<>();
    ArrayList<MCTSCustomer> check = new ArrayList<>();
    ArrayList<MCTSCustomer> visit = new ArrayList<>();

    public MCTSCustomer() {
    }

    public MCTSCustomer(int x, int y, int demand_size, int id) {
        this.x = x;
        this.y = y;
        this.demand_size = demand_size;
        this.id = id;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getId() {
        return id;
    }

    public int getDemand_size() {
        return demand_size;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        MCTSCustomer a = new MCTSCustomer(x,y,demand_size,id);
        visit.add(a);
        this.visited = visited;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        MCTSCustomer a = new MCTSCustomer(x,y,demand_size,id);
        check.add(a);
        this.checked = checked;
    }

    public ArrayList<MCTSCustomer> getCheck() {
        return check;
    }

    public ArrayList<MCTSCustomer> getVisit() {
        return visit;
    }

    public void setSuccessor(ArrayList<MCTSCustomer> successor) {
        this.successor = successor;
        /*
        this.successor.add(new MCTSCustomer(29,17,1,1));
        this.successor.add(new MCTSCustomer(4,50,8,2));
        this.successor.add(new MCTSCustomer(25,13,6,3));
        this.successor.add(new MCTSCustomer(67,37,5,4));
*/
    }
    
    public ArrayList<MCTSCustomer> getSuccessor() {
        return successor;
    }

    @Override
    public String toString() {
        return "Successor{" + "x=" + x + ", y=" + y + ", demand_size=" + demand_size + ", id=" + id;
    }
}
