package JavaApplication115;

import java.util.ArrayList;

public class MCTSTour {
    
    double totalCost;
    MCTSCustomer depot;
    ArrayList<MCTSRoute> tour = new ArrayList<>();
            
    public MCTSTour() {
        
    }

    public MCTSTour(double totalCost) {
        this.totalCost = totalCost;
    }
    
    public void addRoute(MCTSRoute r) {
        tour.add(r);
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }
    
    public double getTotalCost() {
        return totalCost;
    }
    
    public ArrayList<MCTSRoute> getTour() {
        return tour;
    }
    
    public int getSize() {
        return tour.size();
    }
    
    public MCTSRoute getRoute(int i) {
        return tour.get(i);
    }
    
    public void setDepot(MCTSCustomer depot) {
        this.depot = depot;
    }

    public MCTSCustomer getDepot() {
        return depot;
    } 

//    @Override
//    public String toString() {
//        return "Tour{" + "totalCost=" + totalCost + ", tour=" + tour + '}';
//    }
}
