

package JavaApplication115;

import JavaApplication115.MCTSCustomer;
import JavaApplication115.MCTSDataFiltering;
import JavaApplication115.MCTs;
import JavaApplication115.MCTSTour;
import ShanHongPart.GUI_BFS;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.text.Text;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;

import java.awt.font.ImageGraphicAttribute;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.LinkedList;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

/**
 * Author Chin Shan Hong
 */
public class NewFXMain {
    ArrayList<MCTSCustomer> c = new ArrayList<>();
      private static TableView<BestTourData> table;
    private static ObservableList<BestTourData> tabledata;
    private static String filepathupdated;


    public void setFilepathupdated(String filepathupdated) {
        NewFXMain.filepathupdated = filepathupdated;
    }

    public  String getFilepathupdated() {
        return filepathupdated;
    }

    public NewFXMain() {
    }

    public void populateData(MCTSTour bestTour, int vehicleCapacity){
        int[] totalDemandSize = new int[bestTour.getSize()+1]; 
    
        ArrayList<BestTourData> bestTourData = new ArrayList<>();
         String[] route = new String[bestTour.getSize()+1];
        for (int i = 0; i < bestTour.getSize(); i++) {
           
           
            for (int j = 0; j < bestTour.getRoute(i).getSize(); j++) {
                
                if(j==0){
                    route[i]= "0 ->";
                }
                
                else if (j == bestTour.getRoute(i).getSize() - 1) {
                    route[i]+=bestTour.getRoute(i).getCustomer(j).getId() + "\n";
                } 
                
                else {
                    route[i]+=bestTour.getRoute(i).getCustomer(j).getId() +  " -> ";
                }
                 totalDemandSize[i] += bestTour.getRoute(i).getCustomer(j).getDemand_size();
            }
            
            
            
           
            
}

          for(int i = 0; i < bestTour.getSize(); i++){
            int remainingCap = vehicleCapacity - totalDemandSize[i];
            String newI = Integer.toString(i+1);
            String newvehicleCapacity = Integer.toString(vehicleCapacity);
            String remainingCapacity = Integer.toString(remainingCap);
            bestTourData.add(new BestTourData(newI+"",route[i] + "",newvehicleCapacity + "",totalDemandSize[i] +"",remainingCapacity + "",bestTour.getRoute(i).getRouteCost()+""));

        }
        tabledata = FXCollections.observableArrayList(bestTourData);
    }


    public void display() {

        Stage primaryStage = new Stage();

        table = new TableView<>();
        
        int i = 1;
        int j = 1;
        MCTSDataFiltering filter = new MCTSDataFiltering();
        
        ArrayList<String> data = new ArrayList<String>();
        data = filter.filterData(getFilepathupdated());
        int NumOfCustomer = Integer.parseInt(filter.getNumOfCus());
        int vehicleCapacity = Integer.parseInt(filter.getCapacity());

        String line = data.get(j);
        String[] arrLine = line.split(" ");
        int X = Integer.parseInt(arrLine[0]);
        int Y = Integer.parseInt(arrLine[1]);
        MCTSCustomer cs = new MCTSCustomer(X,Y,0,0);
        c.add(cs);
        j = 2;
        while (j <= NumOfCustomer) {
            line = data.get(j);
            arrLine = line.split(" ");

            int x = Integer.parseInt(arrLine[0]);
            int y = Integer.parseInt(arrLine[1]);
            int ds = Integer.parseInt(arrLine[2]);
            cs = new MCTSCustomer(x, y, ds, i);
            c.add(cs);
            i++;
            j++;
        }
        
        System.out.println("Applying MCTS please wait...");
        
        MCTs a = new MCTs(NumOfCustomer, c, vehicleCapacity);
        a.display(a.search(3, 150));
        
  
        MCTSTour bestTour = a.search(3, 150);
             
          // Call populateData() method to add data into the table created
        populateData(bestTour,vehicleCapacity);
        //Initialise Group object to create GUI
        Group group = new Group();
       

        //Create Circle objects for graph visualization
        
        Circle[] circles = initialiseCircleArray(c);
       
        //Add the Circle object into Group object
        getCircle(group, circles, c);
        
//        System.out.println(c);
//
//       Add the Arrow objects into Group objects
        getArrows(group, bestTour, c);
        //Set the label for the display table
        Label label = new Label("Tour Details");
//
        //Set the font type and size of the label
        label.setFont(new Font("Arial", 20));

 // Creating TableColumn objects
        TableColumn vehicleColumn = new TableColumn("Vehicle ID");
        vehicleColumn.setMinWidth(200);
        vehicleColumn.setCellValueFactory(new PropertyValueFactory<MCTSVehicle, String>("vehicleID"));

        TableColumn pathColumn = new TableColumn("Path");
        pathColumn.setMinWidth(200);
        pathColumn.setCellValueFactory(new PropertyValueFactory<MCTSVehicle, String>("vehicleRoute"));

        TableColumn originalCapacityColumn = new TableColumn("Capacity");
        originalCapacityColumn.setMinWidth(200);
        originalCapacityColumn.setCellValueFactory(new PropertyValueFactory<MCTSVehicle, String>("capacity"));

        TableColumn loadColumn = new TableColumn("Load");
        loadColumn.setMinWidth(200);
        loadColumn.setCellValueFactory(new PropertyValueFactory<MCTSVehicle, String>("load"));

        TableColumn remainingCapacityColumn = new TableColumn("Remaining Capacity");
        remainingCapacityColumn.setMinWidth(200);
        remainingCapacityColumn.setCellValueFactory(new PropertyValueFactory<MCTSVehicle, String>("remainingCapacity"));

        TableColumn routeCostColumn = new TableColumn("Route Cost");
        routeCostColumn.setMinWidth(200);
        routeCostColumn.setCellValueFactory(new PropertyValueFactory<MCTSVehicle, String>("vehicleCost"));

        //Add the data into the table
        table.setItems(tabledata);

        //Add the columns into the table
        table.getColumns().addAll(vehicleColumn, pathColumn,originalCapacityColumn, loadColumn, remainingCapacityColumn,routeCostColumn);

        //Create a Text object to display the tour cost in GUI
        Text tourCostDisplay = new Text("Tour Cost: " + bestTour.getTotalCost());
//         System.out.println("MCTSTour Cost done");

        //Set the font size and type of the text
        tourCostDisplay.setFont(new Font("Arial", 20));

          Text simulationTitle = new Text("Monte Carlo Tree Search");
        Font font = Font.font("Arial", FontWeight.BOLD, 30);
        simulationTitle.setFont(font);
        simulationTitle.setFill(Color.BLUE);

        //Create a return button
        Image buttonImage = new Image("/icons/redButton.png");
        ImageView buttonImageView = new ImageView(buttonImage);
        buttonImageView.setFitHeight(30);
        buttonImageView.setFitWidth(30);
        Button returnButton = new Button("Return", buttonImageView);
        returnButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                primaryStage.close();
            }
        });



//        //Create a VBox object for the display layout
        VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 10, 10, 10));
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(simulationTitle, group,label,table, tourCostDisplay, returnButton);
        


        //Create a Scene object
         Scene scene = new Scene(vbox, 300, 300);

        //Set the properties for Stage object
        primaryStage.setTitle("Always On Time Sdn Bhd");
        primaryStage.setWidth(700);
        primaryStage.setHeight(700);
        primaryStage.setScene(scene);
        primaryStage.getIcons().add(new Image("/icons/truck.png"));
        primaryStage.show();

    }

    /**
     * Create an array of Circle object according to the number of vertex
     * @param
     * @return
     */
    public static Circle[] initialiseCircleArray(ArrayList<MCTSCustomer> c){
        Circle[] circles = new Circle[c.size()];
for(int i = 0; i < c.size(); i++){
            //If i == 0, it is depot
            if(i == 0){
                circles[i] = new Circle();
                circles[i].setCenterX(c.get(i).getX() * 2.5);
                circles[i].setCenterY(c.get(i).getY() * 2.5);
                circles[i].setRadius(10);
                circles[i].setFill(Color.RED);
            }
            //If i != 0, it is customer
            else{
                circles[i] = new Circle();
                circles[i].setCenterX(c.get(i).getX() * 2.5);
                circles[i].setCenterY(c.get(i).getY() * 2.5);
                circles[i].setRadius(10);
                circles[i].setFill(Color.CYAN);
            }
        }
        return circles;
    }

    /**
     * Add the Circle and Text object into the Group object
     * @param
     * @param
     * @param
     */
    public static void getCircle(Group group, Circle[] circles,ArrayList<MCTSCustomer> c){
          for(int i = 0 ; i < circles.length; i++){
            //If i == 0, it is depot
            if(i == 0){
            group.getChildren().add(circles[i]);
            group.getChildren().add(new Text(c.get(i).getX() * 2.5 - 15,
                    c.get(i).getY() * 2.5 - 15, "Depot"));

            }
            //If i != 0, it is customer
            else{
                group.getChildren().add(circles[i]);
                group.getChildren().add(new Text(c.get(i).getX() * 2.5 - 15,
                        c.get(i).getY() * 2.5 - 15 , "C" + c.get(i).getId()));
            }
        }
        
    }

    public static void getArrows(Group group, MCTSTour bestTour, ArrayList<MCTSCustomer> c){
//        System.out.println(c);

        for(int i = 0; i < bestTour.getSize(); i++){
            for(int j = 0; j < bestTour.getRoute(i).getSize()-1; j++){
                int vertexID1 = bestTour.getRoute(i).getCustomer(j).getId();
                int vertexID2 = bestTour.getRoute(i).getCustomer(j+1).getId();
//                System.out.println(c.get(vertexID1).getX());
//                System.out.println(c.get(vertexID1).getY());
//                System.out.println(c.get(vertexID2).getX());
//                System.out.println(c.get(vertexID2).getY());
                Arrow arrow = new Arrow(
                        c.get(vertexID1).getX() * 2.5,
                        c.get(vertexID1).getY() * 2.5,
                        c.get(vertexID2).getX() * 2.5,
                        c.get(vertexID2).getY() * 2.5);
                group.getChildren().add(arrow);
            }
        }
    }
    public static class BestTourData {
        private final SimpleStringProperty vehicleID;
        private final SimpleStringProperty vehicleRoute;
        private final SimpleStringProperty capacity;
        private final SimpleStringProperty load;
        private final SimpleStringProperty remainingCapacity;
        private final SimpleStringProperty vehicleCost;

        public BestTourData(String ID,
                           String Route,
                           String capacityInput,
                           String loadInput,
                           String remainingCapacityInput,
                           String Cost) {
            this.vehicleID = new SimpleStringProperty(ID);
            this.vehicleRoute = new SimpleStringProperty(Route);
            this.capacity = new SimpleStringProperty(capacityInput);
            this.load = new SimpleStringProperty(loadInput);
            this.remainingCapacity = new SimpleStringProperty(remainingCapacityInput);
            this.vehicleCost = new SimpleStringProperty(Cost);
        }

         public String getVehicleID() {
            return vehicleID.get();
        }

        public SimpleStringProperty vehicleIDProperty() {
            return vehicleID;
        }

        public void setVehicleID(String vehicleID) {
            this.vehicleID.set(vehicleID);
        }

        public String getVehicleCost(){
            return vehicleCost.get();
        }

        public String getVehicleRoute(){
            return vehicleRoute.get();
        }

        public SimpleStringProperty vehicleRouteProperty() {
            return vehicleRoute;
        }
        public void setVehicleRoute(String vehicleRoute) {
            this.vehicleRoute.set(vehicleRoute);
        }
        public String getRemainingCapacity(){
            return remainingCapacity.get();
        }
        public String getCapacity(){
            return capacity.get();
        }
        public SimpleStringProperty capacityProperty() {
            return capacity;
        }

        public SimpleStringProperty remainingCapacityProperty() {
            return remainingCapacity;
        }
        public SimpleStringProperty vehicleCostProperty() {
            return vehicleCost;
        }

        public String getLoad() {
            return load.get();
        }

        public SimpleStringProperty loadProperty() {
            return load;
        }

        public void setLoad(String load) {
            this.load.set(load);
        }
    }
}

   




