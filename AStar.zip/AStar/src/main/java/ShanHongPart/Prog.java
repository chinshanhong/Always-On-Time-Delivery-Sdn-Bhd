import javax.swing.*;

public class Prog {
    private JPanel panel1;
    private JProgressBar progressBar1;
}
